from cjdarkside import *

start_time = time.time()

spark = SparkSession.builder.master("local[*]").getOrCreate()
today = date.today()

version = '1big'
versionFeaturePL = "PL1big"

gs_model = "gs://cj-demand-forecasting-dataset/model/2021-April-v1/"
gs_csv = "gs://cj-demand-forecasting-dataset/csv/"

PL_FEATURES_PATH = gs_model+"demand_cjdarkside_pl_features_2021_v"+str(versionFeaturePL)+".plmodel"

PL_Bangkok_MODEL_Classification_PATH = gs_model+"demand_cjdarkside_pl_bkk_c_binary_model_2021_v"+str(version)+".plmodel"
PL_Bangkok_MODEL_Regression_PATH = gs_model+"demand_cjdarkside_pl_bkk_r_binary_model_2021_v"+str(version)+".plmodel"

PL_NotBangkok_MODEL_Classification_PATH = gs_model+"demand_cjdarkside_pl_not_bkk_c_binary_model_2021_v"+str(version)+".plmodel"
PL_NotBangkok_MODEL_Regression_PATH = gs_model+"demand_cjdarkside_pl_not_bkk_r_binary_model_2021_v"+str(version)+".plmodel"

PS_DATASET_PATH = "gs://cj-demand-forecasting-dataset/ad_data/ps_agg_v2_0*"

WELFARE_BRANCH_FLAG = "gs://cj-demand-forecasting-dataset/csv/branch_welfare.csv"
WELFARE = "gs://cj-demand-forecasting-dataset/csv/welfare.csv"

branch_location = 'gs://cj-demand-forecasting-dataset/_additional/BranchDistrictTH_EN_2.csv'
welfare_location = 'gs://cj-demand-forecasting-dataset/_additional/csv_branch_welfare.csv'
reference_qty = 'gs://cj-demand-forecasting-dataset/_reference2/reference00*'
flag_qty = 'gs://cj-demand-forecasting-dataset/_additional/flag_sku_branch.csv'

select_variables_initial = ['cj_darkside_id','SalDate','BranchCode','MaterialCode','avgPriceDis',\
                        'avgPrice','supPrice',\
                        'types','ZipCode','ProvinceEN','DistrictEN',\
                        'DayofMonth','Yearday','Month','DayofWeek','Year',\
                        'Quarter','WeekOfYear','MonthQuarter','Branch','Name']

TESTING_DATASET_PATH = "gs://airflow-trigger/Mind/results-20210224-145632.csv"
# df = spark.read.format("csv").option("header", "true").load(TESTING_DATASET_PATH)
# print('gs://{bucket}/{folder}/{file_name}'.format(bucket=bucket,folder=folder,file_name=file_name))
# TESTING_DATASET_PATH = 'gs://{bucket}/{folder}/{file_name}'.format(bucket=bucket,folder=folder,file_name=file_name)

d = pd.read_csv(TESTING_DATASET_PATH,nrows=1,header=None)
df = pd.read_csv(TESTING_DATASET_PATH,skiprows=1)
df.dropna(inplace=True)
df['SalDate'] = df['Date'].astype('datetime64')
df['SalDate'] = df['SalDate'].dt.date
df.drop('Date',axis=1,inplace=True)
df['BranchCode'] = df['BranchCode'].astype('string')
df['BranchCode'] = df['BranchCode'].str.zfill(4)
df_user = spark.createDataFrame(df)
df_key = get_name_branch()
# df_user = df_user.join(df_key,['BranchCode','MaterialCode'],'left').dropDuplicates(['BranchCode','MaterialCode'])
print(df_user.show(5))
email = d[0][0]
list_email = email.lstrip('Email List :').split(',')
# df_user = df.select('BranchCode','MaterialCode','SalDate')
df_pro =price_dis_and_promo_type('2021-01-08')
# df_user = spark.read.format("csv").option("header", "true").load(TESTING_DATASET_PATH)
# df_user = get_mock_file('2021-04-01')
# df_user = get_user_input_df('df_mock_20210221.csv')
df = join_input_with_prc_promo(df_user,df_pro)
df = clean_price_promotion(df)
df_prc = get_product_price()
df = df.join(df_prc,df.MaterialCode == df_prc.MaterialCode_1,how='left')
df = map_price_with_product(df)
df = agg_promo_type(df)
df = df.join(df_key,['BranchCode','MaterialCode'],'left').dropDuplicates(['BranchCode','MaterialCode'])
# df = clean_basic_v2(df)
print(df.show(5))
print('-----------------------------------')
print('-- welcome to the darkside of cj --')
print('-----------------------------------')


weather = map_weather_to_store().drop('name')
df1 = join_df_with_weather(df,weather)
# 
df1 = df1.dropna(how='all')
df2 = encode_holiday(df1)
df3 = encode_welfare(df2)
# 
# PS
# ps = read_file(PS_DATASET_PATH,'csv')
ps = transform_ps()
# 
# TIER
# 
tier = get_tier()
# 
print('starting to join data')
print("--- %s seconds ---" % (time.time() - start_time))
# 
# JOIN PS
df4 = join_df_with_ps(df3,ps)
print('join ps')
print("--- %s seconds ---" % (time.time() - start_time))
# 
# JOIN TIER
df5 = join_df_with_tier(df4,tier)
print('join tier')
print("--- %s seconds ---" % (time.time() - start_time))
# WELFARE FLAG (BRANCH)
welfare_flag = read_file(WELFARE_BRANCH_FLAG,'csv')
df6 = transform_welfare_flag(df5, welfare_flag)
# 
# WELFARE FLAG (DATE)
df7 = transform_welfare_flag_day(df6)
# 
df7.cache()

df8 = one_hot_encoder_promotion(df7,'types')
df9 = one_hot_encoder_holiday(df8,'Holiday')
df10 = one_hot_encoder_holidaytype(df9,'HolidayType')
df11 = encode_tier(df10)

print('complete welfare flag')
print("--- %s seconds ---" % (time.time() - start_time))

print('complete encoder variable (transform to numeric)')
print("--- %s seconds ---" % (time.time() - start_time))

df12 = rename(df11)
df = clean_basic_v2(df12)
print('df12')

# Step1) Create Feature: Location

branch_location_df = spark.read.format("csv").option("header", "true").load(branch_location)
branch_location_df = branch_location_df.withColumnRenamed("BranchCode","BranchCodeLocation")

df = df.join(branch_location_df, df.BranchCode == branch_location_df.BranchCodeLocation)

# Step2) Create Feature: All Play with Date and Welfare

df = df.select("*").withColumn("cj_darkside_id", monotonically_increasing_id())

df = df.withColumnRenamed("Date","SalDate")
df = df.withColumn('DayofMonth', F.dayofmonth(F.col('SalDate')))

df = extract_date(df)

df = select_variable(df, select_variables_initial)

wf = read_file(welfare_location,'csv')
df = transform_welfare_flag(df, wf)
df = transform_welfare_flag_day_2(df)

df = df.withColumnRenamed("types","promotion")

df = df.dropna(how='all')
print('before pipeline')
# load features pipeline
pipeline_features = Pipeline.read().load(PL_FEATURES_PATH)
df_transformed = pipeline_features.fit(df).transform(df)
print('transform')
final_df = clean_binary_2(df_transformed)
final_df.cache()
print(final_df.show(5))

# 
###########################################################################
############### Create Reference Quality Variable #########################
###########################################################################

reference_qty_df = spark.read.format("csv").option("header", "true").load(reference_qty)
reference_qty_df = reference_qty_df.withColumnRenamed("BranchCode","BranchRefQty").withColumnRenamed("MaterialCode","SKURefQty")

reference_qty_df = reference_qty_df.withColumn("BranchRefQty", reference_qty_df["BranchRefQty"].cast("integer"))
reference_qty_df = reference_qty_df.withColumn("SKURefQty", reference_qty_df["SKURefQty"].cast("integer"))

final_df = final_df.join(reference_qty_df,(final_df.BranchCode == reference_qty_df.BranchRefQty) &\
                    (final_df.MaterialCode == reference_qty_df.SKURefQty) &\
                        (final_df.DayofWeek == reference_qty_df.DoW_Num))

###########################################################################
############### Create High Quality Flag Variable #########################
###########################################################################

flag_qty_df = spark.read.format("csv").option("header", "true").load(flag_qty)
#flag_qty_df = flag_qty_df.filter(flag_qty_df.BranchCode.like('%M%') == False)

flag_qty_df = flag_qty_df.dropna()
flag_qty_df = flag_qty_df.withColumn("BranchCode", flag_qty_df["BranchCode"].cast("integer"))
flag_qty_df = flag_qty_df.withColumn("MaterialCode", flag_qty_df["MaterialCode"].cast("integer"))

l_bc = [cj[0] for cj in flag_qty_df.select('BranchCode').distinct().toLocalIterator()]
l_mc = [cj[0] for cj in flag_qty_df.select('MaterialCode').distinct().toLocalIterator()]

matches = (  (F.col('BranchCode').isin(l_bc)) & (F.col('MaterialCode').isin(l_mc))   )
final_df = final_df.withColumn("HighQualityFlag", when(matches, "1").otherwise("0"))

final_df = clean_binary_4(final_df)

print('now features have: ', final_df.columns)
print('now show of data: ', final_df.show(2))
print('now count of data: ', final_df.count())

df_bkk = final_df.filter( (final_df.ProvinceEN.like('%Bangkok%') == True) | (final_df.ProvinceEN.like('%Ratchaburi%') == True)  | (final_df.ProvinceEN.like('%Chon Buri%') == True)\
                    | (final_df.ProvinceEN.like('%Nonthaburi%') == True) | (final_df.ProvinceEN.like('%Nakhon Pathom%') == True)  | (final_df.ProvinceEN.like('%Samut Prakan%') == True)\
                    | (final_df.ProvinceEN.like('%Samut Sakhon%') == True))

df_not_bkk = final_df.filter( (final_df.ProvinceEN.like('%Bangkok%') == False) & (final_df.ProvinceEN.like('%Ratchaburi%') == False)  & (final_df.ProvinceEN.like('%Chon Buri%') == False)\
                        & (final_df.ProvinceEN.like('%Nonthaburi%') == False) & (final_df.ProvinceEN.like('%Nakhon Pathom%') == False)  & (final_df.ProvinceEN.like('%Samut Prakan%') == False)\
                        & (final_df.ProvinceEN.like('%Samut Sakhon%') == False))

print(df_bkk.show(2))
print(df_not_bkk.show(2))

############ ----- LOAD ML MODEL ----- ############

read_plmodelC_BKK = PipelineModel.read().load(PL_Bangkok_MODEL_Classification_PATH)
read_plmodelC_NotBKK = PipelineModel.read().load(PL_NotBangkok_MODEL_Classification_PATH)

print (read_plmodelC_BKK.stages)
print (read_plmodelC_NotBKK.stages)

############ ------------------- ----- ############

#read_model = GBTRegressor.read().load(ML_Bangkok_MODEL_Classification_PATH)

############ ----- DONE ML MODEL ----- ############

predictionsC_BKK = read_plmodelC_BKK.transform(df_bkk)
predictionsC_BKK.cache()

predictionsC_NotBKK = read_plmodelC_NotBKK.transform(df_not_bkk)
predictionsC_NotBKK.cache()

print("Testing Process: Done")

predictionsC = predictionsC_BKK.union(predictionsC_NotBKK)
predictionsC.cache()

############ ----- LOAD ML MODEL ----- ############

read_plmodelR_BKK = PipelineModel.read().load(PL_Bangkok_MODEL_Regression_PATH)
read_plmodelR_NotBKK = PipelineModel.read().load(PL_NotBangkok_MODEL_Regression_PATH)

print (read_plmodelR_BKK.stages)
print (read_plmodelR_NotBKK.stages)

############ ----- DONE ML MODEL ----- ############

predictionsR_BKK = read_plmodelR_BKK.transform(df_bkk)
predictionsR_BKK.cache()

predictionsR_NotBKK = read_plmodelR_NotBKK.transform(df_not_bkk)
predictionsR_NotBKK.cache()

print("Testing Process: Done")

predictionsR = predictionsR_BKK.union(predictionsR_NotBKK)
predictionsR.cache()

def ansByProb(p, t=0.4):
    if p>=t: return 1
    elif p<t: return 0
    else: 0

predictionsA = predictionsC.join(predictionsR,(predictionsC.SalDate == predictionsR.SalDate)&\
                (predictionsC.BranchCode == predictionsR.BranchCode)&\
                (predictionsC.MaterialCode == predictionsR.MaterialCode)).select(predictionsC["*"],predictionsR["predict_qty_lv2"])

split1_udf = udf(lambda value: value[0].item(), FloatType())
split2_udf = udf(lambda value: value[1].item(), FloatType())

predictionsA = predictionsA.withColumn('probability_class0', split1_udf('probability')).withColumn('probability_class1', split2_udf('probability'))

ansByP = F.udf(ansByProb, IntegerType())
predictionsA = predictionsA.withColumn("predict_bi_lv1_with_thresh", ansByP("probability_class1"))

predictionsA = predictionsA.withColumn("predict_qty_final", col("predict_bi_lv1")*col("predict_qty_lv2"))

print(predictionsA.show(2))