# -*- coding: utf-8 -*-
from google.cloud import bigquery
from google.cloud import storage
from google.cloud import dataproc
from datetime import date, timedelta
from pyspark.sql import SparkSession

from  pyspark.sql.functions import abs

from pyspark.sql.functions import monotonically_increasing_id

from pyspark import SparkContext
from pyspark.sql import SparkSession
from pyspark.conf import SparkConf

import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.functions import col,sum

from pyspark.ml import Pipeline, PipelineModel
from pyspark.ml.classification import DecisionTreeClassifier, DecisionTreeClassificationModel
from pyspark.ml.feature import StringIndexer, IndexToString, VectorAssembler,ChiSqSelector, OneHotEncoder
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

from pyspark.ml import Pipeline
from pyspark.ml.regression import GBTRegressor
from pyspark.ml.feature import VectorIndexer
from pyspark.ml.evaluation import RegressionEvaluator

import numpy as np
import pandas as pd

from pyspark.ml.feature import CountVectorizer

from pyspark.sql.functions import when

from pyspark.sql.functions import col,sum

from pyspark.ml.pipeline import PipelineModel

from datetime import date, timedelta

from  pyspark.sql.functions import abs

import time

from pyspark.sql.functions import lit

from datetime import date, timedelta
from pyspark.sql.functions import udf
from pyspark.sql.types import IntegerType
from pyspark.sql.window import Window
import sys
import gcsfs
import json

bucket = str(sys.argv[1])
folder = str(sys.argv[2])
file_name = str(sys.argv[3])
project_id = str(sys.argv[4])
cluster_name = str(sys.argv[5])

start_time = time.time()

spark = SparkSession.builder.master("local[*]").getOrCreate()
today = date.today()

def holiday(dm):
    if dm=='1-1': return 'NewYear'
    elif dm=='5-2':return 'ChineseDay'
    elif dm=='8-4':return 'Chakri'
    elif dm=='13-4':return 'Songkran'
    elif dm=='14-4':return 'Songkran'
    elif dm=='15-4':return 'Songkran'
    elif dm=='16-4':return 'Songkran'
    elif dm=='1-5':return 'Labour'
    elif dm=='6-5':return 'King'
    elif dm=='9-5':return 'Ploughing'
    elif dm=='3-6':return 'Queen'
    elif dm=='12-8':return 'Mother'
    elif dm=='14-10':return 'King9Passing'
    elif dm=='23-10':return 'Chulalongkorn'
    elif dm=='5-12':return 'King9'
    elif dm=='10-12':return 'Constitution'
    elif dm=='24-12':return 'BeforeChristmas'
    elif dm=='25-12':return 'Christmas'
    elif dm=='30-12':return 'NewYearEve'
    elif dm=='31-12':return 'NewYearEve'
    else: return 'Normal'

def holiday_type(dm):
    if dm=='1-1': return 'National'
    elif dm=='5-2':return 'Regional'
    elif dm=='8-4':return 'National'
    elif dm=='13-4':return 'National'
    elif dm=='14-4':return 'National'
    elif dm=='15-4':return 'National'
    elif dm=='16-4':return 'National'
    elif dm=='1-5':return 'National'
    elif dm=='6-5':return 'National'
    elif dm=='9-5':return 'Goverment'
    elif dm=='3-6':return 'National'
    elif dm=='12-8':return 'Public'
    elif dm=='14-10':return 'National'
    elif dm=='23-10':return 'National'
    elif dm=='5-12':return 'Public'
    elif dm=='10-12':return 'National'
    elif dm=='24-12':return 'Public'
    elif dm=='25-12':return 'Public'
    elif dm=='30-12':return 'National'
    elif dm=='31-12':return 'National'
    else: return 'Normal'
    
def welfare(dm):
    if dm=='2019-5': return 500
    elif dm=='2019-6': return 500
    elif dm=='2020-10': return 500
    elif dm=='2020-11': return 500
    elif dm=='2020-12': return 500
    elif dm=='2021-1': return 500
    else: return 700

def tier_convert(t):
    if t=='T1': return 1
    elif t=='T2': return 2
    elif t=='T3': return 3
    elif t=='T4': return 4
    else: return 5

def query_store_location():
    # Configure the query job.
    client = bigquery.Client()
    job_config = bigquery.QueryJobConfig()

    # query location of existing store
    query ='''SELECT code AS BranchCode, lat,lng FROM `thanos-241910.DataMaster.StoreLocation` LIMIT 1000'''
    query_job = client.query(query, job_config=job_config)
    df = query_job.to_dataframe()

    return df

def query_weather():
    # Configure the query job.
    client = bigquery.Client()
    job_config = bigquery.QueryJobConfig()

    # query weather and location of the station in order to map with the store location
    # weather data comes into daily granularity
    # Note : data is lacking for 5 days
    query ='''
        WITH
        weather AS (SELECT
            date,
            temp,
            `max`,
            `min`,
            rain_drizzle,
            wdsp,
            dewp,
            slp,
            visib,
            stn,
            s.name,
            s.lat,
            s.lon
        FROM
            `bigquery-public-data.noaa_gsod.gsod{year}`
        LEFT JOIN
            `bigquery-public-data.noaa_gsod.stations` s
        ON
            stn = usaf
        WHERE
            stn IN (
            SELECT
            DISTINCT usaf
            FROM
            `bigquery-public-data.noaa_gsod.stations`
            WHERE
            country = 'TH') )
        SELECT
        *
        FROM
        weather a
        where 
        a.date=(select MAX(date) from weather b where b.name=a.name)
        '''.format(year = str(today.year))
    query_job = client.query(query, job_config=job_config)
    df = query_job.to_dataframe()

    return df

def map_weather_to_store():
    # join the nearest station with the store in order to map the weather to store
    df_2 = query_store_location()
    df_3 = query_weather()

    df = df_2.assign(foo=1).merge(df_3.assign(foo=1),on='foo').drop('foo', 1)
    df['dis_store'] = ((df['lat_x']-df['lat_y'])**2 + (df['lng']-df['lon'])**2)**(1/2)
    df['Rank'] = df.groupby(['BranchCode'])['dis_store'].rank(ascending=True)
    df = df[df['Rank']==1.0]
    df = df[['BranchCode','name','temp']].reset_index(drop=True)
    df = spark.createDataFrame(df)

    return df
def one_hot_encoder_promotion(df,_input):
    stringIndexer = StringIndexer(inputCol=_input, outputCol="promotion_idx")
    model = stringIndexer.fit(df)
    indexed = model.transform(df)
    encoder = OneHotEncoder(dropLast=False, inputCol="promotion_idx", outputCol="promotion_vec")
    encoded = encoder.transform(indexed)
    df = encoded
    return df

def one_hot_encoder_holiday(df,_input):
    stringIndexer = StringIndexer(inputCol=_input, outputCol="holiday_idx")
    model = stringIndexer.fit(df)
    indexed = model.transform(df)
    encoder = OneHotEncoder(dropLast=False, inputCol="holiday_idx", outputCol="holiday_vec")
    encoded = encoder.transform(indexed)
    df = encoded
    return df

def one_hot_encoder_holidaytype(df,_input):
    stringIndexer = StringIndexer(inputCol=_input, outputCol="holidaytype_idx")
    model = stringIndexer.fit(df)
    indexed = model.transform(df)
    encoder = OneHotEncoder(dropLast=False, inputCol="holidaytype_idx", outputCol="holidaytype_vec")
    encoded = encoder.transform(indexed)
    df = encoded
    return df

def one_hot_encoder_tier(df,_input):
    stringIndexer = StringIndexer(inputCol=_input, outputCol="tier_idx")
    model = stringIndexer.fit(df)
    indexed = model.transform(df)
    encoder = OneHotEncoder(dropLast=False, inputCol="tier_idx", outputCol="tier_vec")
    encoded = encoder.transform(indexed)
    df = encoded
    return df

def string_indexer_tier(df,_input):
    indexer = StringIndexer(inputCol="Tier", outputCol="tier_vec")
    df = indexer.fit(df).transform(df)
    return df

def encode_holiday(df):
  split_col = F.split(df['Date'], '-')

  df = df.withColumn('YYYY', split_col.getItem(0).cast('integer'))\
          .withColumn('MMMM', split_col.getItem(1).cast('integer'))\
          .withColumn('DDDD', split_col.getItem(2).cast('integer'))

  df = df.withColumn('DDDD-MMMM', F.concat(F.col('DDDD'),F.lit('-'), F.col('MMMM')))\
          .withColumn('YYYY-MMMM', F.concat(F.col('YYYY'),F.lit('-'), F.col('MMMM')))
    
  df = df.withColumn('YY', split_col.getItem(0).cast('integer'))
  df = df.withColumn('MM', split_col.getItem(1).cast('integer'))
  
  #print('Size of Original Data Set: ',(df.count(), len(df.columns)))

  holiday_func1 = F.udf(holiday, StringType())
  holiday_func2 = F.udf(holiday_type, StringType())
  
  
  df = df.withColumn("Holiday", holiday_func1("DDDD-MMMM"))\
          .withColumn("HolidayType", holiday_func2("DDDD-MMMM"))
  
  df = df.withColumnRenamed("Branchcode","BranchCode")
  
  df = df.withColumn("BranchCode", df.BranchCode.cast("integer"))\
          .withColumn("MaterialCode", df.MaterialCode.cast("integer"))
  return df

def encode_tier(df):
    
  tier_func1 = F.udf(tier_convert, StringType())

  df = df.withColumn("TierNumeric", tier_func1("Tier"))
  return df

def encode_welfare(df):
  welfare_func1 = F.udf(welfare, StringType())
  df = df.withColumn("Welfare", welfare_func1("YYYY-MMMM"))
  return df

# dfx = spark.read.format("csv").option("header", "true").load(PS_DATASET_PATH)
def transform_ps(df):
    
    # Branch,MaterialCode,MedianSkuBranch
    df = df.withColumn("Branch", df.Branch.cast("integer"))\
            .withColumn("MaterialCode", df.MaterialCode.cast("integer"))

    df = df.withColumnRenamed("f0_","Price_Sensitivity")\
            .withColumnRenamed("Branch","BC2")\
            .withColumnRenamed("MaterialCode","MC2")
    return df

def transform_tier(df):
  df = df.withColumn("BranchCode", df.BranchCode.cast("integer"))\
          .withColumn("MaterailCode", df.MaterailCode.cast("integer"))

  df = df.withColumnRenamed("BranchCode","BC3")\
          .withColumnRenamed("MaterailCode","MC3")
  return df

def transform_welfare_flag(df, df_welfare_flag):
    df_welfare_flag = welfare_flag.toPandas()
    df_welfare_flag = df_welfare_flag.branchcode.astype(int)
    wf_flag_list = df_welfare_flag.values.tolist()

    matches = df["BranchCode"].isin(wf_flag_list)
    new_df = df.withColumn("welfareFlag", when(matches, "1").otherwise("0"))
    
    return new_df

def transform_welfare_flag_day(df):
    matches = df["DDDD"].isin([1,2,3,4,5])
    new_df = df.withColumn("welfareFlagDay", when(matches, "1").otherwise("0"))
    
    return new_df

def join_df_with_ps(df,ps):

    df = df.join(ps, (df.BranchCode == ps.BC2) & (df.MaterialCode == ps.MC2),how='left')  

    split_col = F.split(df['Date'], '-')

    df = df.withColumn('YY', split_col.getItem(0).cast('integer'))
    df = df.withColumn('MM', split_col.getItem(1).cast('integer'))
    
    df = df.withColumn("BranchCode", df["BranchCode"].cast("integer"))\
            .withColumn("MaterialCode", df["MaterialCode"].cast("integer"))
    return df

def tier():
    client = bigquery.Client()
    job_config = bigquery.QueryJobConfig()
    query = '''SELECT 
    CALMONTH,
    PLANT BranchCode,
    MATERIAL  MaterailCode,
    ZTIER Tier
    FROM `thanos-241910.SAPBW.AZENHT012`
    '''
    query_job = client.query(query, job_config=job_config)
    df = query_job.to_dataframe()
    df['CALYEAR'] = df['CALMONTH'].apply(lambda x : x[0:4])
    df['CALMONTH'] = df['CALMONTH'].apply(lambda x : int(x[-2:]))
    try:
        df = spark.createDataFrame(df)
        df = df.select(['BranchCode', 'MaterailCode', 'CALYEAR', 'CALMONTH', 'Tier'])

    except:
        pass

    df = df.withColumn("BranchCode", df["BranchCode"].cast("integer"))\
            .withColumn("MaterailCode", df["MaterailCode"].cast("integer"))

    df = df.withColumnRenamed("BranchCode","BC3")\
            .withColumnRenamed("MaterailCode","MC3")
    
    return df
    
def join_df_with_tier(df,tier):
    return df.join(tier, (df.BranchCode == tier.BC3) & (df.MaterialCode == tier.MC3)) #& \
                #    (df.YY == tier.CALYEAR) & (df.MM == tier.CALMONTH),how='left')

def join_df_with_weather(df,weather):
    return df.join(weather,['Branchcode'],how = 'left')

def clean(df):
    df = df.dropna(how='all')
    df = df.dropna()
    df = df.withColumn("welfareFlag", df["welfareFlag"].cast('integer'))
    df = df.withColumn("welfareFlagDay", df["welfareFlagDay"].cast('integer'))
    df = df.withColumn("supPrice", df["supPrice"].cast('integer'))
    df = df.withColumn("BranchCode", df["BranchCode"].cast("integer"))
    df = df.withColumn("MaterialCode", df["MaterialCode"].cast('integer'))
    df = df.withColumn("avgPriceDis", df["avgPriceDis"].cast('double'))
    df = df.withColumn("Welfare", df["Welfare"].cast('integer'))
    df = df.withColumn("TierNumeric", df["TierNumeric"].cast('integer'))
    df = df.withColumn("avgPrice", df["avgPrice"].cast('double'))
    df = df.withColumn("Price_Sensitivity", df["Price_Sensitivity"].cast('double'))
    df = df.withColumn("temp", df["temp"].cast('double'))
    return df

def rename(df):
    df = df.withColumnRenamed("DDDD","Day")\
            .withColumnRenamed("MMMM","Month")\
            .withColumnRenamed("YYYY","Year")
    return df

def select_variable(df,select_list):
    df = df.select(select_list)
    return df

def read_file(df,_format):
  return spark.read.format(str(_format)).option("header", "true").load(df)

def write_result(df,name):
  df.toPandas().to_csv('gs://cj-demand-forecasting-dataset/demand_prediction_pipeline/result/result_{name}_{date}.csv'\
    .format(name = name, date = (str(today.year)+str(today.month)+str(today.day))),index=False)


def price_dis_and_promo_type(date):
    client = bigquery.Client()
    # Configure the query job.
    job_config = bigquery.QueryJobConfig()
    query = '''
    WITH temp_pro as (
    SELECT  
    a.DocNo
    ,a.StartDate
    ,a.EndDate
    ,b.MaterialCode
    ,b.Barcode
    ,b.MaterialName
    --,b.barfactor
    ,b.UnitName
    ,a.Name
    ,case when a.BuyGrpCode=b.GrpCode then 'ซื้อ'
        when a.wthgrpcode=b.GrpCode then 'ร่วม' else 'รับ' end as ProGroup
    ,case when a.BuyGrpCode=b.GrpCode then a.BuySum
        when a.wthgrpcode=b.GrpCode then a.WthSum else a.GetSum end as ProCondition
    ,case when a.BuyGrpCode=b.GrpCode and a.BuyType = '1' then 'ชิ้น'
        when a.BuyGrpCode=b.GrpCode and a.BuyType <> '1' then 'บาท'
        when a.wthgrpcode=b.GrpCode and a.WthType = '1' then 'ชิ้น'
        when a.wthgrpcode=b.GrpCode and a.WthType <> '1' then 'บาท'
        when a.GetGrpCode=b.GrpCode and a.GetType = '1' then 'ชิ้น'
        else 'บาท' end as Unit
    ,case when d.DisType = '1' then 'ลดบาท'
        when d.DisType = '2' then 'ลด%'
        when d.DisType = '3' then 'ปรับราคา'
        else 'ฟรี' end as ProConditionType
    ,d.GetDis GetValue
    ,bar.RetailPriceExpress
    ,bar.RetailPriceValue
    ,case when a.RefCode ='001' then 'โปรสมาชิกใหม่'
     when a.RefCode = '002' then 'โปรสมาชิกเก่า' else '-' end as MemberPromotion
    ,case when a.DocStatus = '2' then 'อนุมัติ' else 'ไม่อนุมัติ' end as DocStatus
    ,case when a.IsActive = '1' then 'ใช้งาน' else 'หยุดโปร' end as PromotionStatus
    FROM `thanos-241910.DataMaster.POSPromotionHD` a 
    left join `thanos-241910.DataMaster.POSPromotionDT` d on d.DocNo=a.DocNo
    inner join `thanos-241910.DataMaster.POSPromotionGroupMember` b on a.BuyGrpCode=b.GrpCode or a.wthgrpcode=b.GrpCode or a.GetGrpCode=b.GrpCode
    left join `thanos-241910.DataMaster.POSBarcode` bar on bar.Barcode=b.Barcode
     WHERE CreateDate >= "{}" and bar.UnitCode = 'ST')

    SELECT StartDate,
    EndDate,
    MaterialCode,
    GetValue as avgPriceDis,
    RetailPriceExpress as avgPrice,
    RetailPriceExpress as supPrice,
    ZPRO_TYPE as Type,
    case when Unit = 'ชิ้น' then ProCondition else 1 end as Procondition,
    FROM temp_pro                 
     LEFT JOIN `thanos-241910.SAPBW.AZWAKH00` as type
     ON temp_pro.DocNo = type.RT_PROMO 
    '''.format(date)

    # Run the query.
    query_job = client.query(query, job_config=job_config)
    df = query_job.to_dataframe()
    df = spark.createDataFrame(df)
    df = df.withColumn('MaterialCode_1',df['MaterialCode'].cast('integer')).drop('MaterialCode')
    return df
def get_product_price():
    client = bigquery.Client()
    # Configure the query job.
    job_config = bigquery.QueryJobConfig()
    query = '''
    SELECT MaterialCode,
    RetailPriceExpress
    FROM
    `thanos-241910.DataMaster.POSBarcode`
    where UnitCode = 'ST'
    '''
    # Run the query.
    query_job = client.query(query, job_config=job_config)
    df = query_job.to_dataframe()
    df = spark.createDataFrame(df)
    df = df.withColumn('MaterialCode_1',df['MaterialCode'].cast('integer')).drop('MaterialCode')
    return df
    
def get_user_input_df(path):
    df = pd.read_csv(path)
    df = spark.createDataFrame(df)
    return df

def join_input_with_prc_promo(usr_input,prc_promo):
    # join input file from user and price&promotion type
    return usr_input.join(prc_promo,(usr_input.Date.between(prc_promo.StartDate,prc_promo.EndDate))\
                          &(usr_input.MaterialCode==prc_promo.MaterialCode_1) \
                          ,how = 'left').drop('MaterialCode_1')

def map_price_with_product(df):
    df = df.withColumn('avgPriceDis',when(df.avgPriceDis.isNull(),df.RetailPriceExpress).otherwise(df.min))\
            .withColumn('avgPrice',when(df.avgPrice.isNull(),df.RetailPriceExpress).otherwise(df.avgPrice))\
            .withColumn('supPrice',when(df.supPrice.isNull(),df.RetailPriceExpress).otherwise(df.supPrice))\
            .withColumn('Type',when(df.Type.isNull(),'NORMAL').otherwise(df.Type))
    return df
    
def agg_promo_type(df):
    return df.groupby(['Date','BranchCode','MaterialCode','avgPriceDis','avgPrice','supPrice'])\
            .agg(F.concat_ws("|", F.collect_set("Type")).alias("types"))

def clean_price_promotion(df):
    w =  Window.partitionBy(df.MaterialCode)

    df = df.withColumn('new_prc',df.avgPriceDis/df.Procondition)
    df = df.withColumn('percent_cng',1-(df.new_prc/df.avgPrice))
    df = df.withColumn('avgPriceDis',when(df.percent_cng <=0.5,df.new_prc).otherwise(df.avgPrice))
    df = df.withColumn('max',F.max(df.avgPriceDis).over(w))\
        .withColumn('min',F.min(df.avgPriceDis).over(w))
    return df

def get_mock_file(date):
    client = bigquery.Client()
    # Configure the query job.
    job_config = bigquery.QueryJobConfig()
    query = '''
    SELECT 
    MATERIAL as MaterialCode,
    PLANT as BranchCode
    FROM `thanos-241910.SAPBW.ADR_LAST`
    where PLANT like '0%' and MATERIAL like '0000000%20%'
    '''
    # Run the query.
    query_job = client.query(query, job_config=job_config)
    df = query_job.to_dataframe()
    df = spark.createDataFrame(df)
    df = df.dropDuplicates(['BranchCode','MaterialCode'])
    df = df.withColumn('Date',lit(date))
    df = df.withColumn('MaterialCode',df['MaterialCode'].cast('integer'))
    return df
    

if __name__ == '__main__':
    try:
        #load model
        version = '9c_cluster'
        MODEL_PATH = "gs://cj-demand-forecasting-dataset/model/2021-Jan/demand_model_2021_v"+str(version)+".pkl"
        MODEL_PATH_C = "gs://cj-demand-forecasting-dataset/model/2021-Jan/demand_model_2021_v"+str(version)+"_C.pkl"
        MODEL_PATH_C0 = "gs://cj-demand-forecasting-dataset/model/2021-Jan/demand_model_2021_v"+str(version)+"_C0.pkl"
        MODEL_PATH_C1 = "gs://cj-demand-forecasting-dataset/model/2021-Jan/demand_model_2021_v"+str(version)+"_C1.pkl"
        MODEL_PATH_C2 = "gs://cj-demand-forecasting-dataset/model/2021-Jan/demand_model_2021_v"+str(version)+"_C2.pkl"

        # TESTING_DATASET_PATH = "gs://cj-demand-forecasting-dataset/demand_data_prep_v4/data00000000004*"
        # TESTING_DATASET_PATH = "gs://cj-demand-forecasting-dataset/demand_prediction_pipeline/daily_sale_summary/sale_sum_{}.csv"\
        # .format(str(today.year)+str(today.month)+str(today.day))
        # TESTING_DATASET_PATH = "gs://airflow-trigger/*.csv"
        print('gs://{bucket}/{folder}/{file_name}'.format(bucket=bucket,folder=folder,file_name=file_name))
        TESTING_DATASET_PATH = 'gs://{bucket}/{folder}/{file_name}'.format(bucket=bucket,folder=folder,file_name=file_name)

        PS_DATASET_PATH = "gs://cj-demand-forecasting-dataset/ad_data/ps_agg_v2_0*"
        TIER_DATASET_PATH = "gs://cj-demand-forecasting-dataset/tier/tier00*"
        # OS_DATASET_PATH = "gs://cj-demand-forecasting-dataset/nooos/nooos00*"

        WELFARE_BRANCH_FLAG = "gs://cj-demand-forecasting-dataset/csv/branch_welfare.csv"
        WELFARE = "gs://cj-demand-forecasting-dataset/csv/welfare.csv"
        d = pd.read_csv(TESTING_DATASET_PATH,nrows=1,header=None)
        df = pd.read_csv(TESTING_DATASET_PATH,skiprows=1)
        df.dropna(inplace=True)
        df['Date'] = df['Date'].astype('datetime64')
        df['Date'] = df['Date'].dt.date
        df_user = spark.createDataFrame(df)
        print(df_user.show(5))
        email = d[0][0]
        list_email = email.lstrip('Email List :').split(',')
        
        # SQLContext.getOrCreate(sc).clearCache()
        df_pro =price_dis_and_promo_type('2021-01-08')
        # df_user = spark.read.format("csv").option("header", "true").load(TESTING_DATASET_PATH)
        # df_user = get_mock_file('2021-02-01')
        # df_user = get_user_input_df('df_mock_20210221.csv')
        df = join_input_with_prc_promo(df_user,df_pro)
        df = clean_price_promotion(df)
        df_prc = get_product_price()
        df = df.join(df_prc,df.MaterialCode == df_prc.MaterialCode_1,how='left')
        df = map_price_with_product(df)
        df = agg_promo_type(df)
        df.cache()
        print(df.show(5))
        # df = spark.read.format("csv").option("header", "true").load(TESTING_DATASET_PATH)

        print('-----------------------------------')
        print('-- welcome to the darkside of cj --')
        print('-----------------------------------')

        # df.cache()
        print('count: before sampling: ', df.count())
        #df = df.sample(False, 0.01, 2021)
        #print('count: after sampling: ', df.count())

        # JOIN WEATHER
        weather = map_weather_to_store()
        df = join_df_with_weather(df,weather)

        df2 = encode_holiday(df)
        df3 = encode_welfare(df2)

        # PS
        ps = read_file(PS_DATASET_PATH,'csv')
        ps = transform_ps(ps)

        # TIER
        # tier = read_file(TIER_DATASET_PATH,'csv')
        tier = tier()
        # tier = transform_tier(tier)


        print('starting to join data')
        print("--- %s seconds ---" % (time.time() - start_time))

        # JOIN PS
        df4 = join_df_with_ps(df3,ps)
        print('join ps')
        print("--- %s seconds ---" % (time.time() - start_time))

        # JOIN TIER
        df5 = join_df_with_tier(df4,tier)
        df5 = df5.repartition(100)
        print('join tier')
        print("--- %s seconds ---" % (time.time() - start_time))

        # WELFARE FLAG (BRANCH)
        welfare_flag = read_file(WELFARE_BRANCH_FLAG,'csv')
        df6 = transform_welfare_flag(df5, welfare_flag)

        # WELFARE FLAG (DATE)
        df7 = transform_welfare_flag_day(df6)

        df7.cache()

        df8 = one_hot_encoder_promotion(df7,'types')
        df9 = one_hot_encoder_holiday(df8,'Holiday')
        df10 = one_hot_encoder_holidaytype(df9,'HolidayType')
        df11 = encode_tier(df10)

        #df11 = string_indexer_tier(df8,'Tier')


        print('complete welfare flag')
        print("--- %s seconds ---" % (time.time() - start_time))


        print('now size of data: ', df11.count())

        print('complete encoder variable (transform to numeric)')
        print("--- %s seconds ---" % (time.time() - start_time))

        select_variables = ['BranchCode', 'MaterialCode', 'avgPriceDis', 'avgPrice',\
                    'supPrice', 'Year', 'Month', 'Day', 'temp', 'Price_Sensitivity',\
                    'promotion_idx', 'promotion_vec', 'holiday_idx', 'holiday_vec', 'holidaytype_idx',\
                    'holidaytype_vec', 'Welfare', 'welfareFlag','welfareFlagDay','TierNumeric']

        df12 = rename(df11)
        df = clean(df12)

        final_df = select_variable(df, select_variables)

        final_df.cache()

        print('now features have: ', final_df.columns)
        print('now show of data: ', final_df.show(3))
        print('now count of data: ', final_df.count())

        # select features for model
        select_variables = ['BranchCode', 'MaterialCode', 'avgPriceDis', 'avgPrice',\
                'supPrice', 'Year', 'Month', 'Day', 'temp', 'Price_Sensitivity',\
                'promotion_idx', 'promotion_vec', 'holiday_idx', 'holiday_vec', 'holidaytype_idx',\
                'holidaytype_vec', 'Welfare', 'welfareFlag','welfareFlagDay','TierNumeric']

        select_variables_cluster = ['avgPriceDis', 'avgPrice',\
                    'supPrice', 'Month', 'Day', 'Price_Sensitivity']

        final_df.cache()
        final_df_cluster = select_variable(final_df,select_variables_cluster)
        final_df_2 = select_variable(final_df,select_variables)

        # Clustering
        persistedModel_C = PipelineModel.load(MODEL_PATH_C)
        predictions = persistedModel_C.transform(final_df_cluster)
        predictions_c = predictions.select("prediction").withColumn("id1", monotonically_increasing_id())
        final_df_2_c = final_df_2.select("*").withColumn("id2", monotonically_increasing_id())
        final_df_2_c = final_df_2_c.join(predictions_c, (final_df_2_c.id2 == predictions_c.id1), how='left')

        #Cluster 0
        final_df = final_df_2_c.filter(col('prediction') == 0)
        model = PipelineModel.load(MODEL_PATH_C0)
        predictions = model.transform(final_df)

        #Cluster 1
        final_df = final_df_2_c.filter(col('prediction') == 1)
        model = PipelineModel.load(MODEL_PATH_C1)
        predictions1 = model.transform(final_df)

        #Cluster 2
        final_df = final_df_2_c.filter(col('prediction') == 2)
        model = PipelineModel.load(MODEL_PATH_C2)
        predictions2 = model.transform(final_df)

        # concat all predictions
        final_predictions = (predictions.union(predictions1)).union(predictions2)
        final_predictions = final_predictions.withColumn("Date", F.to_date(F.concat_ws("-", "Year", "Month", "Day")))
        final_predictions = final_predictions.withColumn("BranchCode",F.format_string("%04d","BranchCode").cast("string"))
        #write the result
        write_result(final_predictions,'demand')
        final_predictions.toPandas().to_csv('gs://result-demand-forecasting/{folder}/result_{file_name}.csv'\
        .format(folder = folder,file_name = file_name.split('.csv')[0]),index=False)
        
        # delete cluster
        print('Deleting Cluster')
        dataproc_client = dataproc.ClusterControllerClient()
        result = dataproc_client.delete_cluster(request={"project_id": project_id, "region": 'global', "cluster_name": cluster_name})
        print('Complete')
        # create metadata of each file
        metadata = {'create_date':str(today),
                    'input_bucket': bucket,
                    'output_bucket':'result-demand-forecasting',
                    'folder':folder,
                    'cluster_name':cluster_name,
                    'file_name':'result_{file_name}.csv'.format(file_name = file_name.split('.csv')[0]),
                    'email':list_email}

        bucket_name = 'demand_input_trigger'
        bucket = storage.Client().get_bucket(bucket_name)
        blob = bucket.blob('{folder}/metadata_{file_name}.json'.format(folder = folder,file_name = file_name))
        # take the upload outside of the for-loop otherwise you keep overwriting the whole file
        blob.upload_from_string(data=json.dumps(metadata),content_type='application/json')  
        print("Testing Process: Done")
    except Exception as e:
        print(e)
        print('Deleting Cluster')
        dataproc_client = dataproc.ClusterControllerClient()
        result = dataproc_client.delete_cluster(request={"project_id": project_id, "region": 'global', "cluster_name": cluster_name})
        print('Complete')
